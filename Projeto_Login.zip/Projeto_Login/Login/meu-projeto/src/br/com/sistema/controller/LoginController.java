package br.com.sistema.controller;

import br.com.sistema.model.AutenticacaoModel;
import br.com.sistema.model.UsuarioModel;
import br.com.sistema.view.CadastroView;
import br.com.sistema.view.LoginView;

import java.awt.Color;

public class LoginController {

    private AutenticacaoModel authModel;
    private LoginView loginView;

    public LoginController(AutenticacaoModel authModel, LoginView loginView) {
        this.authModel = authModel;
        this.loginView = loginView;

        // Ação do Botão Entrar
        this.loginView.addEntrarListener(e -> {
            String user = loginView.getLogin();
            String pass = loginView.getSenha();

            if (user.isEmpty() || pass.isEmpty()) {
                loginView.exibirMensagem("Preencha login e senha!", Color.RED);
                return;
            }

            if (authModel.autenticar(user, pass)) {
                loginView.dispose(); // Fecha a tela de login

                // Abre a tela principal de cadastros
                UsuarioModel model = new UsuarioModel();
                CadastroView view = new CadastroView();
                int i = 1;
                for (String nome : model.getUsuarios()) {
                    view.adicionarLinhaTabela(i++, nome);
                }
                new CadastroController(model, view);
                view.setVisible(true);
            } else {
                loginView.exibirMensagem("Login ou senha incorretos!", Color.RED);
            }
        });

        // Ação do Botão Novo Usuário (Cadastro de acesso)
        this.loginView.addCadastrarListener(e -> {
            String user = loginView.getLogin();
            String pass = loginView.getSenha();

            if (user.isEmpty() || pass.isEmpty()) {
                loginView.exibirMensagem("Preencha login e senha para cadastrar!", Color.RED);
                return;
            }

            if (authModel.cadastrarNovoUsuario(user, pass)) {
                loginView.exibirMensagem("Usuário registrado com sucesso!", new Color(0, 128, 0));
                loginView.limparCampos();
            } else {
                loginView.exibirMensagem("Erro: Login já existe!", Color.RED);
            }
        });
    }
}