package br.com.sistema.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class LoginView extends JFrame {

    private JTextField txtLogin = new JTextField(15);
    private JPasswordField txtSenha = new JPasswordField(15);
    private JButton btnEntrar = new JButton("Entrar");
    private JButton btnCadastrar = new JButton("Novo Usuário");
    private JLabel lblStatus = new JLabel(" ", SwingConstants.CENTER);

    public LoginView() {
        setTitle("Acesso ao Sistema");
        setSize(380, 240);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // 1. Define o tom de azul desejado (Ex: Azul Marinho)
        Color corAzulFundo = new Color(20, 20, 20);
        getContentPane().setBackground(corAzulFundo);

        // 2. Painel de Campos
        JPanel painelCampos = new JPanel(new GridLayout(2, 2, 8, 8));
        painelCampos.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        painelCampos.setBackground(corAzulFundo); // Pinta o fundo do painel

        JLabel lblLogin = new JLabel("Login:");
        lblLogin.setForeground(Color.WHITE); // Texto branco para contrastar

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setForeground(Color.WHITE); // Texto branco para contrastar

        painelCampos.add(lblLogin);
        painelCampos.add(txtLogin);
        painelCampos.add(lblSenha);
        painelCampos.add(txtSenha);

        // 3. Painel de Botões
        JPanel painelBotoes = new JPanel(new FlowLayout());
        painelBotoes.setBackground(corAzulFundo); // Pinta o fundo do painel
        painelBotoes.add(btnEntrar);
        painelBotoes.add(btnCadastrar);

        add(painelCampos, BorderLayout.NORTH);
        add(painelBotoes, BorderLayout.CENTER);
        add(lblStatus, BorderLayout.SOUTH);
    }

    public String getLogin() { return txtLogin.getText(); }
    public String getSenha() { return new String(txtSenha.getPassword()); }
    public void limparCampos() { txtLogin.setText(""); txtSenha.setText(""); txtLogin.requestFocus(); }
    
    public void exibirMensagem(String msg, Color cor) { 
        // Se passar vermelho no controller, clareia um pouco para aparecer bem no fundo escuro
        if (cor.equals(Color.RED)) {
            lblStatus.setForeground(new Color(255, 100, 100));
        } else {
            lblStatus.setForeground(new Color(100, 255, 120));
        }
        lblStatus.setText(msg); 
    }

    public void addEntrarListener(ActionListener l) { btnEntrar.addActionListener(l); }
    public void addCadastrarListener(ActionListener l) { btnCadastrar.addActionListener(l); }
}