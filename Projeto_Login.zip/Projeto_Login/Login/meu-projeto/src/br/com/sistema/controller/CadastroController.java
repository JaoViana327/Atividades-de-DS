package br.com.sistema.controller;

import br.com.sistema.model.UsuarioModel;
import br.com.sistema.view.CadastroView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroController {
    private UsuarioModel model;
    private CadastroView view;

    public CadastroController(UsuarioModel model, CadastroView view) {
        this.model = model;
        this.view = view;

        this.view.addCadastrarListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processarCadastro();
            }
        });
    }

    private void processarCadastro() {
        String nome = view.getNomeDigitado();

        if (nome == null || nome.trim().isEmpty()) {
            view.exibirMensagemErro("Aviso: Digite um nome para cadastrar!");
            return;
        }

        model.adicionarUsuario(nome);
        int id = model.getTotalUsuarios();
        view.adicionarLinhaTabela(id, nome.trim());
        view.exibirMensagemSucesso("Cadastrado com sucesso!");
        view.limparCampoNome();
    }
}